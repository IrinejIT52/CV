﻿namespace DiskontPica.Repository
{
	public class Principal
	{
		public string name { get; set; }
		public string password { get; set; }
	}
}
