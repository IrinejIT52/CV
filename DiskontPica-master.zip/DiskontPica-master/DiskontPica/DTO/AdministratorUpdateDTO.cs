﻿namespace DiskontPica.DTO
{
	public class AdministratorUpdateDTO
	{
		public string name {  get; set; }
		public string password { get; set; }
		public string email { get; set; }
	}
}
