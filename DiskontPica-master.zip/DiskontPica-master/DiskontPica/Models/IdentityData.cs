﻿namespace DiskontPica.Models
{
	public class IdentityData
	{
		public const string AdminClaim = "admin";

		public const string AdminPolicy = "Admin";

		public const string CustomerClaim = "customer";

		public const string CustomerPolicy = "Customer";
	}
}
