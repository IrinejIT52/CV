﻿namespace DiskontPica.Models
{
	public enum OrderType
	{
		REGULAR,
		BIRTHDAY,
		ANNIVERSERY,
		PARTY
	}
}
