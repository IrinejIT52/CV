﻿namespace DiskontPica.Models
{
	public enum OrderStatus
	{
		PENDING,
		CONFIRMED,
		CANCELLED
	}
}
