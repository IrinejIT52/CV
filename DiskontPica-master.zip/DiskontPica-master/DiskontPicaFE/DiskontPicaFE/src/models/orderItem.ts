export class OrderItem {
    orderId!:number;
    orderItemId!:number;
    productId!:number;
    quantity!:number;
    priceQuantity!:number;
}