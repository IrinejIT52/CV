export class Principal {
    name!:string;
    password!:string;
}