export class Product {
    productId!:number;
    name!:string;
    description!:string;
    price!:number;
    stock!:number;
    countryId!:number;
    categoryId!:number;
    adminId!:number;
}