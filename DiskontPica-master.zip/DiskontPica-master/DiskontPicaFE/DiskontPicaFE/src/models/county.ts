export class Country{
    countryId!:number;
    name!:string;
}