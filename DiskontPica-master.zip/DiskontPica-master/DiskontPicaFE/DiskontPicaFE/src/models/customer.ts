export class Customer{
    customerId!:number;
    name!:string;
    password!:string;
    email!:string;
    adress!:string;
    salt!:string;
}