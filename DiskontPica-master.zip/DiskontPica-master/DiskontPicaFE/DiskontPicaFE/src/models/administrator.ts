export class Administrator {
    adminId!:number;
    name!:string;
    password!:string;
    email!:string;
    salt!:string;
}