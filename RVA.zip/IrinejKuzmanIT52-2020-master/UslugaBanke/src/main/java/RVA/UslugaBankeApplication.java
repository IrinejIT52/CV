package RVA;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;



@SpringBootApplication
public class UslugaBankeApplication {

	public static void main(String[] args) {
		SpringApplication.run(UslugaBankeApplication.class, args);
		
	}

}
