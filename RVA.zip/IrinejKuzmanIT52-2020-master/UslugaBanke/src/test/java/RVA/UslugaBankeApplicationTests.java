package RVA;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UslugaBankeApplicationTests {

	@Test
	void contextLoads() {
	}

}
