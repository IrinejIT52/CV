export const BANKA_URL = 'http://localhost:8081/banka';
export const KORISNIK_URL = 'http://localhost:8081/korisnik'
export const FILIJALA_URL = 'http://localhost:8081/filijala'
export const USLUGA_URL = 'http://localhost:8081/usluga'
export const USLUGA_PO_KORISNIKU_URL = 'http://localhost:8081/uslugaPoKorisniku'
