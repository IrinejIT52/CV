export class Banka {
    idBanke!:number;
    nazivBanke!:string;
    kontaktBanke!:string;
    pib!:number;

}