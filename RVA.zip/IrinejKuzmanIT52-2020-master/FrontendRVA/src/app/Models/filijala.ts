import { Banka } from "./banka";

export class Filijala {
    idFilijale!:number;
    adresaFilijale!:string;
    brojPultova!:number;
    posjedujeSefa!:boolean;
    banka!:Banka;

}