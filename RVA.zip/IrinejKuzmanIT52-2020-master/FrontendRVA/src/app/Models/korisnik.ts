export class Korisnik {
    idKorisnika!:number;
    imeKorisnika!:string;
    prezimKorisnika!:string;
    maticniBroj!:string;


}