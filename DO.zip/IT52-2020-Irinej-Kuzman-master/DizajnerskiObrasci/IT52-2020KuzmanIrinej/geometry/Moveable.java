package geometry;

public interface Moveable {

	void moveTo(int x,int y);
	void moveBy(int byX, int byY);
	
}
