insert into currency_exchange(id,currency_from,currency_to,exchange_value)
values(1,'EUR','RSD',117);

insert into currency_exchange(id,currency_from,currency_to,exchange_value)
values(2,'EUR','USD',1.10);

insert into currency_exchange(id,currency_from,currency_to,exchange_value)
values(3,'EUR','GBP',0.86);

insert into currency_exchange(id,currency_from,currency_to,exchange_value)
values(4,'EUR','CHF',0.98);

insert into currency_exchange(id,currency_from,currency_to,exchange_value)
values(5,'USD','RSD',120);

insert into currency_exchange(id,currency_from,currency_to,exchange_value)
values(6,'USD','EUR',0.91);

insert into currency_exchange(id,currency_from,currency_to,exchange_value)
values(7,'USD','GBP',0.78);

insert into currency_exchange(id,currency_from,currency_to,exchange_value)
values(8,'USD','CHF',0.90);

insert into currency_exchange(id,currency_from,currency_to,exchange_value)
values(9,'GBP','RSD',140);

insert into currency_exchange(id,currency_from,currency_to,exchange_value)
values(10,'GBP','EUR',1.16);

insert into currency_exchange(id,currency_from,currency_to,exchange_value)
values(11,'GBP','USD',1.27);

insert into currency_exchange(id,currency_from,currency_to,exchange_value)
values(12,'GBP','CHF',1.14);

insert into currency_exchange(id,currency_from,currency_to,exchange_value)
values(13,'CHF','RSD',115);

insert into currency_exchange(id,currency_from,currency_to,exchange_value)
values(14,'CHF','EUR',1.02);

insert into currency_exchange(id,currency_from,currency_to,exchange_value)
values(15,'CHF','USD',1.12);

insert into currency_exchange(id,currency_from,currency_to,exchange_value)
values(16,'CHF','GBP',0.88);

insert into currency_exchange(id,currency_from,currency_to,exchange_value)
values(17,'RSD','EUR',0.0085);

insert into currency_exchange(id,currency_from,currency_to,exchange_value)
values(18,'RSD','USD',0.0093);

insert into currency_exchange(id,currency_from,currency_to,exchange_value)
values(19,'RSD','GBP',0.0073);

insert into currency_exchange(id,currency_from,currency_to,exchange_value)
values(20,'RSD','GBP',0.0084);