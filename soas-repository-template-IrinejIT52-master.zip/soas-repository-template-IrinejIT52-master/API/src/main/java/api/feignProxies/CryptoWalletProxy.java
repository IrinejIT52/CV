package api.feignProxies;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestParam;

@FeignClient("crypto-wallet")
public interface CryptoWalletProxy {
	
	@DeleteMapping("/crypto-wallet/{email}")
	public void deleteWallet(@PathVariable("email") String email);
	
	@GetMapping("/crypto-wallet/{email}/{cryptoFrom}")
	Double getUserCryptoAmount(@PathVariable("email") String email,@PathVariable("cryptoFrom") String cryptoFrom);
	
	@PutMapping("/crypto-wallet/wallet")
	ResponseEntity<?> updateWalletCurrency(@RequestParam("email") String email, @RequestParam("from") String from,
			@RequestParam("to") String to, @RequestParam("quantity") double quantity, @RequestParam("totalAmount") double totalAmount);

}
