package api.dtos;

import com.fasterxml.jackson.annotation.JsonIgnore;



public class AccountCurrenciesDto {

	private String currency;
	
    private Double amount;

    private BankAccountDto bankAccount;



	public String getCurrency() {
		return currency;
	}
	

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	public BankAccountDto getBankAccount() {
		return bankAccount;
	}

	public void setBankAccount(BankAccountDto bankAccount) {
		this.bankAccount = bankAccount;
	}
}
