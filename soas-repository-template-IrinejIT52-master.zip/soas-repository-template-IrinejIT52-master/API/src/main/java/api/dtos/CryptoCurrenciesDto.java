package api.dtos;



public class CryptoCurrenciesDto {

	private String crypto;
	
    private Double amount;
  
   
    private CryptoWalletDto cryptoWallet;
    
    public CryptoCurrenciesDto() {
    	
    }



	public String getCrypto() {
		return crypto;
	}

	public void setCrypto(String crypto) {
		this.crypto = crypto;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	public CryptoWalletDto getCryptoWallet() {
		return cryptoWallet;
	}

	public void setCryptoWallet(CryptoWalletDto cryptoWallet) {
		this.cryptoWallet = cryptoWallet;
	}
}
