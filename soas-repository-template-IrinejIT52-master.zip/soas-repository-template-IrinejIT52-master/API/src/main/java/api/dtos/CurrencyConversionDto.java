package api.dtos;

import java.math.BigDecimal;

public class CurrencyConversionDto {

	// atributi kao kod CurrencyExchange klase
	private String from;
	private String to;
	private BigDecimal exchangeValue;
	private String environment;

	// Specificno za CurrencyConversion
	private BigDecimal conversionTotal;
	private Double quantity;

	public CurrencyConversionDto() {

	}

	public CurrencyConversionDto(String from, String to, BigDecimal exchangeValue, String environment,
			Double quantity, BigDecimal conversionTotal) {
		this.from = from;
		this.to = to;
		this.exchangeValue = exchangeValue;
		this.environment = environment;
		this.conversionTotal = conversionTotal;
		this.quantity = quantity;
	}

	public String getFrom() {
		return from;
	}

	public void setFrom(String from) {
		this.from = from;
	}

	public String getTo() {
		return to;
	}

	public void setTo(String to) {
		this.to = to;
	}

	public BigDecimal getExchange() {
		return exchangeValue;
	}

	public void setExchange(BigDecimal exchangeValue) {
		this.exchangeValue = exchangeValue;
	}

	public String getEnvironment() {
		return environment;
	}

	public void setEnvironment(String environment) {
		this.environment = environment;
	}

	public BigDecimal getConversionTotal() {
		return conversionTotal;
	}

	public void setConversionTotal(BigDecimal conversionTotal) {
		this.conversionTotal = conversionTotal;
	}

	public Double getQuantity() {
		return quantity;
	}

	public void setQuantity(Double quantity) {
		this.quantity = quantity;
	}
}
