package api.dtos;

import java.util.List;


public class CryptoWalletDto {

	 	private List<CryptoCurrenciesDto> currencies;
		

		private String email;
		
		public CryptoWalletDto() {
			
		}

		

		public List<CryptoCurrenciesDto> getCurrencies() {
			return currencies;
		}

		public void setCurrencies(List<CryptoCurrenciesDto> currencies) {
			this.currencies = currencies;
		}

		public String getEmail() {
			return email;
		}

		public void setEmail(String email) {
			this.email = email;
		}
}
