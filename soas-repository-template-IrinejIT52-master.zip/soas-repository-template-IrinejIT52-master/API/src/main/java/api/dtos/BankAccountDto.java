package api.dtos;

import java.util.List;



public class BankAccountDto {

	 	private List<AccountCurrenciesDto> currencies;
		
		private String email;
		
		public BankAccountDto() {
			
		}

		

		public List<AccountCurrenciesDto> getCurrencies() {
			return currencies;
		}

		public void setCurrencies(List<AccountCurrenciesDto> currencies) {
			this.currencies = currencies;
		}

		public String getEmail() {
			return email;
		}

		public void setEmail(String email) {
			this.email = email;
		}
}
