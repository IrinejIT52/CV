package api.services;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import api.dtos.CryptoWalletDto;

public interface CryptoWalletService {

	@GetMapping("/crypto-wallet")
	public ResponseEntity<List<CryptoWalletDto>> getAllWallets();
	
	@PostMapping("/crypto-wallet")
	public ResponseEntity<?> createWallet(@RequestBody CryptoWalletDto wallet);
	
	@PutMapping("/crypto-wallet/{walletID}")
	public ResponseEntity<?> updateWallet(@PathVariable("walletID") long walletID, @RequestBody CryptoWalletDto updateWallet);
	
	@DeleteMapping("/crypto-wallet/{email}")
	public void deleteWallet(@PathVariable("email") String email);
	
	@GetMapping("/crypto-wallet/{email}/{cryptoFrom}")
	public Double getUserCryptoAmount(@PathVariable("email") String email, @PathVariable("cryptoFrom") String cryptoFrom);
	
	@PutMapping("/crypto-wallet/wallet")
	public ResponseEntity<?> updateWalletCurrency(@RequestParam String email, @RequestParam String from,
			@RequestParam String to, @RequestParam double quantity, @RequestParam double totalAmount);
}
