package CryptoExchange.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import CryptoExchange.models.CryptoExchange;


public interface CryptoExchangeRepository extends JpaRepository<CryptoExchange, Integer> {

	CryptoExchange findByFromAndTo(String from, String to);
}
