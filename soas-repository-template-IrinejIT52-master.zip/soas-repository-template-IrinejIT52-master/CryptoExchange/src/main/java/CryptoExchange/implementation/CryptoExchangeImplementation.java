package CryptoExchange.implementation;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import CryptoExchange.models.CryptoExchange;
import CryptoExchange.repository.CryptoExchangeRepository;
import api.dtos.CryptoExchangeDto;
import api.dtos.CurrencyExchangeDto;
import api.services.CryptoExchangeService;

@RestController
public class CryptoExchangeImplementation implements CryptoExchangeService {

	
	@Autowired
	private CryptoExchangeRepository repo;
	
	@Autowired
	private Environment environment;
	
	
	@Override
	public ResponseEntity<?> getExchange(@RequestParam String from,@RequestParam String to) {
		CryptoExchange model = repo.findByFromAndTo(from, to);
		if(model == null) {
			return ResponseEntity.status(404).body(
					"Requested exchange pair [" + from + " into " + to + "] could not be found"
					);
		}
		return ResponseEntity.ok(convertModelToDto(model));
	}

	@Override
	public ResponseEntity<?> getExchangePath(@PathVariable String from,@PathVariable String to) {
		CryptoExchange model = repo.findByFromAndTo(from, to);
		if(model == null) {
			return ResponseEntity.status(404).body(
					"Requested exchange pair [" + from + " into " + to + "] could not be found"
					);
		}
		return ResponseEntity.ok(convertModelToDto(model));
	}
	
	public CryptoExchangeDto convertModelToDto(CryptoExchange model) {
		CryptoExchangeDto dto = 
				new CryptoExchangeDto(model.getFrom(), model.getTo(), model.getExchangeValue());
		dto.setInstancePort(environment.getProperty("local.server.port"));
		return dto;
	}

}
