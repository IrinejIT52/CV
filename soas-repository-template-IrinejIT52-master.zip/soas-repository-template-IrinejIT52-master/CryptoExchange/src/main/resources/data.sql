insert into crypto_exchange(id,crypto_from,crypto_to,exchange_value)
values(1,'BTC','ETH',117);

insert into crypto_exchange(id,crypto_from,crypto_to,exchange_value)
values(2,'BTC','BNB',1.10);

insert into crypto_exchange(id,crypto_from,crypto_to,exchange_value)
values(3,'ETH','BTC',0.86);

insert into crypto_exchange(id,crypto_from,crypto_to,exchange_value)
values(4,'ETH','BNB',0.98);

insert into crypto_exchange(id,crypto_from,crypto_to,exchange_value)
values(5,'BNB','BTC',120);

insert into crypto_exchange(id,crypto_from,crypto_to,exchange_value)
values(6,'BNB','ETH',0.91);
