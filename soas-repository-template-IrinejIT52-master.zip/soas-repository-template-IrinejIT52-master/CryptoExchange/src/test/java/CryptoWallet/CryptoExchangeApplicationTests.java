package CryptoWallet;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import CryptoExchange.CryptoExchangeApplication;

@SpringBootTest(classes = CryptoExchangeApplication.class)
class CryptoExchangeApplicationTests {

	@Test
	void contextLoads() {
	}

}
