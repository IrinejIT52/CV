## SOAS Projekat
***

**Credentials:**


## OWNER: 
- **EMAIL:** owner@gmail.com
- **PASSWORD:** 123

## ADMIN:
- **EMAIL:** admin@gmail.com
- **PASSWORD:** 123
	
	
## USER1:
- **EMAIL:** user1@gmail.com
- **PASSWORD:** 123
	
## USER2:
- **EMAIL:** user2@gmail.com
- **PASSWORD:** 123
	
	
## USER3:
- **EMAIL:** user3@gmail.com
- **PASSWORD:** 123


***

## Paths:

## USERS SERVICE: http://localhost:8765/users/
***
## Get Users
- **Method:** GET
- **Path:** `/users`
- **Description:** Retrieves a list of users.
- **Response:** List of `UserDto`

## Create User
- **Method:** POST
- **Path:** `/users/newUser`
- **Description:** Creates a new user.
- **Request Body:** `UserDto`
- **Request Header:** `Authorization`
- **Response:** `ResponseEntity<?>`

## Update User
- **Method:** PUT
- **Path:** `/users/{id}`
- **Description:** Updates a user with the specified ID.
- **Request Body:** `UserDto`
- **Request Header:** `Authorization`
- **Response:** `ResponseEntity<?>`

## Delete User
- **Method:** DELETE
- **Path:** `/users/{id}`
- **Description:** Deletes a user with the specified ID.
- **Request Header:** `Authorization`
- **Response:** `ResponseEntity<?>`

## Get User by Email
- **Method:** GET
- **Path:** `/users/by-email/{email}`
- **Description:** Checks if a user exists with the given email.
- **Path Variable:** `email`
- **Response:** `Boolean`

## Get User's Role by Email
- **Method:** GET
- **Path:** `/users/by-email-role/{email}`
- **Description:** Retrieves the role of a user with the specified email.
- **Path Variable:** `email`
- **Response:** `String`

## Get Current User's Role
- **Method:** GET
- **Path:** `/users/current-user-role`
- **Description:** Retrieves the role of the current user.
- **Request Header:** `Authorization`
- **Response:** `String`

## Get Current User's Email
- **Method:** GET
- **Path:** `/users/current-user-email`
- **Description:** Retrieves the email of the current user.
- **Request Header:** `Authorization`
- **Response:** `String`
***

## BANK SERVICE: http://localhost:8765/bank-account/

***
## Get All Accounts
- **Method:** GET
- **Path:** `/bank-account`
- **Description:** Retrieves all bank accounts.
- **Response:** `List<BankAccount>`

## Get User Accounts
- **Method:** GET
- **Path:** `/bank-account/{email}`
- **Path Variable:** `email`
- **Description:** Retrieves users bank account.
- **Response:** `BankAccount`

## Create Account
- **Method:** POST
- **Path:** `/bank-account`
- **Description:** Creates a new bank account.
- **Request Body:** `BankAccount`
- **Response:** `ResponseEntity<?>`

## Update Account
- **Method:** PUT
- **Path:** `/bank-account/{accountID}`
- **Description:** Updates a bank account with the specified ID.
- **Path Variable:** `accountID`
- **Request Body:** `BankAccount`
- **Response:** `ResponseEntity<?>`

## Delete Account
- **Method:** DELETE
- **Path:** `/bank-account/{email}`
- **Description:** Deletes a bank account associated with the given email.
- **Path Variable:** `email`

## Get User Currency Amount
- **Method:** GET
- **Path:** `/bank-account/{email}/{currencyFrom}`
- **Description:** Retrieves the amount of the specified currency for a user.
- **Path Variables:** `email`, `currencyFrom`
- **Response:** `Double`

## Update Account Currency
- **Method:** PUT
- **Path:** `/bank-account/account`
- **Description:** Updates the currency amount for a bank account.
- **Request Parameters:** `email`, `from`, `to`, `quantity`, `totalAmount`
- **Response:** `ResponseEntity<?>`
***

## CURRENCY EXCHANGE SERVICE: http://localhost:8765/currency-exchange/
***
### Get exchange
- **HTTP Method:** `GET`
- **Endpoint:** `/currency-exchange`
- **Query Parameters:**
  - `from` (String): The currency you want to exchange from.
  - `to` (String): The currency you want to exchange to.

- **HTTP Method:** `GET`
- **Endpoint:** `/currency-exchange/path/from/{from}/to/{to}`
- **Path Variables:**
  - `from` (String): The currency you want to exchange from.
  - `to` (String): The currency you want to exchange to.
***

## CURRENCY CONVERSION SERVICE: http://localhost:8765/currency-conversion/
***
### Get exchange
- **HTTP Method:** `GET`
- **Endpoint:** `/currency-conversion/from/{from}/to/{to}/quantity/{quantity}`
- **Path Variables:**
  - `from` (String): The currency you want to exchange from.
  - `to` (String): The currency you want to exchange to.
  - `quantity` (Double): The currency number you convert.
  
- **Method:** GET
- **Path:** `"/currency-conversion-feign"`
- **Description:** Updates the currency amount for a bank account.
- **Request Parameters:** `from`, `to`, `quantity`, `authorizationHeader`
- **Response:** `ResponseEntity<?>`
***

## CRYPTO WALLET SERVICE: http://localhost:8765/crypto-wallet/
***
## Get All Wallets
- **Method:** GET
- **Path:** `/crypto-wallet`
- **Description:** Retrieves all crypto wallets.
- **Response:** `List<CryptoWallet>`

## Get User Wallet
- **Method:** GET
- **Path:** `/crypto-wallet/{email}`
- **Path Variable:** `email`
- **Description:** Retrieves users crypto wallet.
- **Response:** `CryptoWallet`

## Create Wallet
- **Method:** POST
- **Path:** `/crypto-wallet`
- **Description:** Creates a new crypto wallet.
- **Request Body:** `CryptoWallet`
- **Response:** `ResponseEntity<?>`

## Update Wallet
- **Method:** PUT
- **Path:** `/crypto-wallet/{walletID}`
- **Description:** Updates a crypto wallet with the specified ID.
- **Path Variable:** `walletID`
- **Request Body:** `CryptoWallet`
- **Response:** `ResponseEntity<?>`

## Delete Wallet
- **Method:** DELETE
- **Path:** `/crypto-wallet/{email}`
- **Description:** Deletes a crypto wallet associated with the given email.
- **Path Variable:** `email`

## Get User Currency Amount
- **Method:** GET
- **Path:** `/crypto-wallet/{email}/{cryptoFrom}`
- **Description:** Retrieves the amount of the specified currency for a user.
- **Path Variables:** `email`, `cryptoFrom`
- **Response:** `Double`

## Update Wallet Currency
- **Method:** PUT
- **Path:** `/crypto-wallet/wallet`
- **Description:** Updates the crypto amount for a crypto wallet.
- **Request Parameters:** `email`, `from`, `to`, `quantity`, `totalAmount`
- **Response:** `ResponseEntity<?>`
***

## CRYPTO EXCHANGE SERVICE: http://localhost:8765/crypto-exchange/
***
### Get exchange
- **HTTP Method:** `GET`
- **Endpoint:** `/crypto-exchange`
- **Query Parameters:**
  - `from` (String): The crypto you want to exchange from.
  - `to` (String): The crypto you want to exchange to.

- **HTTP Method:** `GET`
- **Endpoint:** `/crypto-exchange/path/from/{from}/to/{to}`
- **Path Variables:**
  - `from` (String): The crypto you want to exchange from.
  - `to` (String): The crypto you want to exchange to.
***

## CRYPTO CONVERSION SERVICE: http://localhost:8765/crypto-conversion/
***
### Get exchange
- **HTTP Method:** `GET`
- **Endpoint:** `/crypto-conversion/from/{from}/to/{to}/quantity/{quantity}`
- **Path Variables:**
  - `from` (String): The crypto you want to exchange from.
  - `to` (String): The crypto you want to exchange to.
  - `quantity` (Double): The crypto number you convert.
  
- **Method:** GET
- **Path:** `"/crypto-conversion-feign"`
- **Description:** Updates the crypto amount for a bank account.
- **Request Parameters:** `from`, `to`, `quantity`, `authorizationHeader`
- **Response:** `ResponseEntity<?>`
***


