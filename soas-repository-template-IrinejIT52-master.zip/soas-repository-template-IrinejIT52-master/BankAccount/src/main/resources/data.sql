insert into bank_account(accountID,email)
values(1,'user1@gmail.com');


insert into account_currencies(id,currency,amount,accountID)
values(1,'EUR',15.00,1);
insert into account_currencies(id,currency,amount,accountID)
values(2,'USD',20.00,1);
insert into account_currencies(id,currency,amount,accountID)
values(3,'GBP',30.00,1);
insert into account_currencies(id,currency,amount,accountID)
values(4,'RSD',40.00,1);
insert into account_currencies(id,currency,amount,accountID)
values(5,'CHF',60.00,1);