package BankAccount.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import BankAccount.models.BankAccount;

public interface BankAccountRepository extends JpaRepository<BankAccount, Long> {

	boolean existsByEmail(String email);

	BankAccount findByEmail(String email);
}
