package BankAccount.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import BankAccount.models.AccountCurrencies;

public interface AccountCurrencyRepository extends JpaRepository<AccountCurrencies, Long> {

}
