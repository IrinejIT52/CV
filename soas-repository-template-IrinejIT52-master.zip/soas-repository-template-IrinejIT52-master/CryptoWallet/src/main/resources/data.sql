insert into crypto_wallet(walletID,email)
values(1,'user1@gmail.com');


insert into crypto_currencies(id,crypto,amount,walletID)
values(1,'BTC',15.00,1);
insert into crypto_currencies(id,crypto,amount,walletID)
values(2,'ETH',200.00,1);
insert into crypto_currencies(id,crypto,amount,walletID)
values(3,'BNB',300.00,1);
