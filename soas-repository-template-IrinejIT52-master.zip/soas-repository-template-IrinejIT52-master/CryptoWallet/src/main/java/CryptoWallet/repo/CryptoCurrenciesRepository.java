package CryptoWallet.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import CryptoWallet.models.CryptoCurrencies;

public interface CryptoCurrenciesRepository extends JpaRepository<CryptoCurrencies, Long>{

}
