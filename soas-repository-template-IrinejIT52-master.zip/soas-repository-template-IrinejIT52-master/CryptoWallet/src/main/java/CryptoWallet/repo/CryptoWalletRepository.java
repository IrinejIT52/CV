package CryptoWallet.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import CryptoWallet.models.CryptoWallet;

public interface CryptoWalletRepository extends JpaRepository<CryptoWallet, Long> {

	boolean existsByEmail(String email);

	CryptoWallet findByEmail(String email);
}
