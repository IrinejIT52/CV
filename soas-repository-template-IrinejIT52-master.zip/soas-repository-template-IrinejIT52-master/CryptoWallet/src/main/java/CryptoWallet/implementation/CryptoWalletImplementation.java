package CryptoWallet.implementation;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import CryptoWallet.models.CryptoCurrencies;
import CryptoWallet.models.CryptoWallet;
import CryptoWallet.repo.CryptoCurrenciesRepository;
import CryptoWallet.repo.CryptoWalletRepository;
import api.feignProxies.UserProxy;
import feign.FeignException.Unauthorized;

@RestController
public class CryptoWalletImplementation {

	@Autowired
	private CryptoWalletRepository repo;
	
	@Autowired
	private CryptoCurrenciesRepository repoCurr;
	
	@Autowired
	private UserProxy proxy;
	
	@GetMapping("/crypto-wallet")
	public ResponseEntity<List<CryptoWallet>> getAllWallets() {
		List<CryptoWallet> lista=repo.findAll();
		return ResponseEntity.ok(lista);
	}
	
	@GetMapping("/crypto-wallet/{email}")
	public ResponseEntity<CryptoWallet> getUserWallet(@PathVariable String email,@RequestHeader("Authorization") String authorizationHeader) {
		String userEmail = proxy.getCurrentUserEmail(authorizationHeader);
		if(userEmail.matches(email)) {
			CryptoWallet wallet=repo.findByEmail(email);
			return ResponseEntity.ok(wallet);
		}
		else 
			return null;
		
	}
	
	
	
	@PostMapping("/crypto-wallet")
	public ResponseEntity<?> createWallet(@RequestBody CryptoWallet wallet) {
		if (repo.existsById(wallet.getWalletID())) {
			String errorMessage = "Wallet with passed id already exists.";
			return ResponseEntity.status(HttpStatus.CONFLICT).body(errorMessage);
		} else {
			if (!repo.existsByEmail(wallet.getEmail())) {
				Boolean emailUser = proxy.getUser(wallet.getEmail()); 
				
				if (emailUser.equals(false)) {
					String errorMessage = "User with email doesn't exist.";
					return ResponseEntity.status(HttpStatus.NOT_FOUND).body(errorMessage);
				} else {
					String roleUser = proxy.getUsersRole(wallet.getEmail()); 
					
					if (!roleUser.equals("USER")) {
						String errorMessage = "User doesn't have role 'USER'.";
						return ResponseEntity.status(HttpStatus.NOT_FOUND).body(errorMessage);
					} else {
						List<CryptoCurrencies> crypto = new ArrayList<>();
						CryptoWallet createdWallet = repo.save(wallet);
						for (CryptoCurrencies currency : wallet.getCurrencies()) {
							currency.setCryptoWallet(createdWallet);
							CryptoCurrencies savedCurrency = repoCurr.save(currency);
							crypto.add(savedCurrency);
						}
						createdWallet.setCurrencies(crypto);
						return new ResponseEntity<>(createdWallet, HttpStatus.CREATED);
					}
				}
			} else {
				String errorMessage = "This user already have an crypto wallet.";
				return ResponseEntity.status(HttpStatus.CONFLICT).body(errorMessage);
			}
		}
	}
	
	
	
	@PutMapping("/crypto-wallet/{walletID}")
	public ResponseEntity<?> updateWallet(@PathVariable long walletID, @RequestBody CryptoWallet updateWallet) {
		CryptoWallet existingWallet = repo.findById(walletID).orElse(null);
		if (existingWallet == null) {
			String errorMessage = "The wallet with passed id doesn't exists.";
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(errorMessage);
		} else {
			if (existingWallet.getEmail().equals(updateWallet.getEmail())) {
				for (CryptoCurrencies currency : updateWallet.getCurrencies()) {
					currency.setCryptoWallet(existingWallet);
					repoCurr.save(currency);
				}
				CryptoWallet updatedWallet = repo.save(updateWallet);
				return ResponseEntity.ok(updatedWallet);
			} else {
				String errorMessage = "You can't update wallet email.";
				return ResponseEntity.status(HttpStatus.CONFLICT).body(errorMessage);

			}
		}
	}
	
	
	@DeleteMapping("/crypto-wallet/{email}")
	public void deleteWallet(@PathVariable String email) {
		CryptoWallet cryptoWallet = repo.findByEmail(email);
		if (cryptoWallet != null) {
			repo.delete(cryptoWallet);
		}
	}
	
	
	
	
	@GetMapping("/crypto-wallet/{email}/{cryptoFrom}")
	public Double getUserCryptoAmount(@PathVariable String email, @PathVariable String cryptoFrom) {
		CryptoWallet userWallet = repo.findByEmail(email);
		List<CryptoCurrencies> userCurrencies = userWallet.getCurrencies();
		for (CryptoCurrencies walletCurrency : userCurrencies) {
			if (walletCurrency.getCrypto().equals(cryptoFrom)) {
				return walletCurrency.getAmount();
			}
		}
		return null;
	}
	
	
	
	@PutMapping("/crypto-wallet/wallet")
	public ResponseEntity<?> updateWalletCurrency(@RequestParam String email, @RequestParam String from,
			@RequestParam String to, @RequestParam double quantity, @RequestParam double totalAmount) {
		CryptoWallet existingWallet = repo.findByEmail(email);
		if (existingWallet == null) {
			String errorMessage = "The wallet with the passed id does not exist.";
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(errorMessage);
		} else {
			List<CryptoCurrencies> currenciesInWallet = existingWallet.getCurrencies();
			CryptoCurrencies fromCrypto = null;
			CryptoCurrencies toCrypto = null;

			for (CryptoCurrencies crypto : currenciesInWallet) {
				if (crypto.getCrypto().equals(from)) {
					fromCrypto = crypto;
				}
				if (crypto.getCrypto().equals(to)) {
					toCrypto = crypto;
				}

			}
			double fromCryptoAmount = fromCrypto.getAmount();
			if(fromCryptoAmount>0) {
				fromCrypto.setAmount(fromCryptoAmount - quantity);
			if (toCrypto == null) {
				toCrypto = new CryptoCurrencies();
				toCrypto.setCrypto(to);
				toCrypto.setAmount(totalAmount);
				toCrypto.setCryptoWallet(existingWallet);

				currenciesInWallet.add(toCrypto);
			} else {
				double toCryptoAmount = toCrypto.getAmount();
				toCrypto.setAmount(toCryptoAmount + totalAmount);
			}
			repoCurr.save(fromCrypto);
			repoCurr.save(toCrypto);
			CryptoWallet updatedWallet = repo.save(existingWallet);
			return ResponseEntity.ok(updatedWallet);
			}
			else {
				String errorMessage = "There is no enoguh amount for conversion.";
				return ResponseEntity.status(HttpStatus.CONFLICT).body(errorMessage);
			}
		}
	}
	
	
}
