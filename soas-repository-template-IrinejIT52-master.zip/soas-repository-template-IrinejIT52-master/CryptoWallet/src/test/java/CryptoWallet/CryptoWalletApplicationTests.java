package CryptoWallet;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CryptoWalletApplicationTests {

	@Test
	void contextLoads() {
	}

}
