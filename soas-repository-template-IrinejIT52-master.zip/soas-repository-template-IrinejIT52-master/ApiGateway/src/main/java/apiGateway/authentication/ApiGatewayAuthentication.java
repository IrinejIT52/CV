package apiGateway.authentication;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authorization.AuthorizationDecision;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.reactive.EnableWebFluxSecurity;
import org.springframework.security.config.web.server.ServerHttpSecurity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.MapReactiveUserDetailsService;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.server.SecurityWebFilterChain;
import org.springframework.security.web.server.authorization.AuthorizationContext;

import org.springframework.web.client.RestTemplate;

import api.dtos.UserDto;
import reactor.core.publisher.Mono;

@Configuration
@EnableWebFluxSecurity
public class ApiGatewayAuthentication {

	@Bean
	SecurityWebFilterChain filterChain(ServerHttpSecurity http) {
		http.
		csrf(csrf -> csrf.disable())
		.authorizeExchange(exchange -> exchange.pathMatchers("/currency-exchange/**").permitAll()
				.pathMatchers("/crypto-exchange/**").permitAll()
				.pathMatchers("/currency-conversion/**").access(this::ConversionAccess)
				.pathMatchers("/crypto-conversion/**").access(this::ConversionAccess)
				.pathMatchers("/bank-account/**").access(this::bankWallet)
				.pathMatchers("/users/**").access(this::userAccess)
				.pathMatchers("/crypto-wallet/**").access(this::bankWallet)
				
				)
				.httpBasic(Customizer.withDefaults());
		
		return http.build();
	}
	
	
	@Bean
	MapReactiveUserDetailsService userDetailsService(BCryptPasswordEncoder encoder) {
		
		// Obratiti paznju na URL prilikom dokerizacije
		// Van dokera vrednost URL je localhost:8770/users
		// U dokeru vrednost URL mora biti users-service:8770/users
		ResponseEntity<List<UserDto>> response = new RestTemplate()
				.exchange("http://localhost:8770/users", HttpMethod.GET, null,
						new ParameterizedTypeReference<List<UserDto>> () {});
		
		List<UserDetails> users = new ArrayList<UserDetails>();
		for(UserDto dto: response.getBody()) {
			users.add(
					User.withUsername(dto.getEmail())
					.password(encoder.encode(dto.getPassword()))
					.roles(dto.getRole())
					.build()
					);
		}
		
		return new MapReactiveUserDetailsService(users);
	}
	
	@Bean
	BCryptPasswordEncoder getEncoder() {
		return new BCryptPasswordEncoder();
	}
	
	 private Mono<AuthorizationDecision> userAccess(Mono<Authentication> authentication, AuthorizationContext context) {
	        return authentication.map(auth -> {
	            String role = auth.getAuthorities().iterator().next().getAuthority();
	            HttpMethod method = context.getExchange().getRequest().getMethod();
	            String path = context.getExchange().getRequest().getURI().getPath();

	            switch (role) {
	                case "ROLE_OWNER":
	                    return new AuthorizationDecision(true); // OWNER can add, update, and delete all users
	                case "ROLE_ADMIN":
	                    if (method==HttpMethod.GET || method==HttpMethod.POST || method==HttpMethod.PUT) {
	                        // ADMIN can add or update users with role USER
	                        // Here, you need to validate that the target user is of role USER
	                        // This is a placeholder check; adjust it according to your actual request validation logic.
	                        return new AuthorizationDecision(true);
	                    }
	                    return new AuthorizationDecision(false);
	                case "ROLE_USER":
	                    return new AuthorizationDecision(false); // USER has no access
	                default:
	                    return new AuthorizationDecision(false);
	            }
	        });
	 }
	 
	 private Mono<AuthorizationDecision> ConversionAccess(Mono<Authentication> authentication, AuthorizationContext context) {
	        return authentication.map(auth -> {
	            String role = auth.getAuthorities().iterator().next().getAuthority();
	            if ("ROLE_USER".equals(role)) {
	                return new AuthorizationDecision(true); // USER has access
	            }
	            // OWNER and ADMIN do not have access
	            return new AuthorizationDecision(false);
	        });
	    }
	 
	 
	  private Mono<AuthorizationDecision> bankWallet(Mono<Authentication> authentication, AuthorizationContext context) {
	        return authentication.map(auth -> {
	            String role = auth.getAuthorities().iterator().next().getAuthority();
	            HttpMethod method = context.getExchange().getRequest().getMethod();
	            System.out.print(role);
	            switch (role) {
	                case "ROEL_OWNER":
	                    return new AuthorizationDecision(false); // OWNER is not authorized
	                case "ROLE_ADMIN":
	                    return new AuthorizationDecision(true); // ADMIN can add, update, and view all bank accounts
	                case "ROLE_USER":
	                    if (method==HttpMethod.GET) {
	                    	// USER can view wallet
	                        return new AuthorizationDecision(true);
	                    }
	                    return new AuthorizationDecision(false);
	                default:
	                    return new AuthorizationDecision(false);
	            }
	        });
	    }
	 
	 
}
