package CryptoConversion;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CryptoConversionApplicationTests {

	@Test
	void contextLoads() {
	}

}
