package usersService.implementation;

import java.util.ArrayList;
import java.util.List;
import org.bouncycastle.util.encoders.Base64;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import api.dtos.UserDto;
import api.feignProxies.BankAccountProxy;
import api.services.UsersService;
import usersService.model.UserModel;
import usersService.repository.UsersServiceRepository;


@RestController
public class UsersServiceImplementation implements UsersService {

	@Autowired
	private UsersServiceRepository repo;
	
	@Autowired
	private BankAccountProxy proxy;
	
   
	
	
	@Override
	public List<UserDto> getUsers() {
		List<UserModel> listOfModels = repo.findAll();
		ArrayList<UserDto> listOfDtos = new ArrayList<UserDto>();
		for(UserModel model: listOfModels) {
			listOfDtos.add(convertModelToDto(model));
		}
		return listOfDtos;
	}


	@Override
	public ResponseEntity<?> createUser(UserDto dto,@RequestHeader("Authorization") String authorizationHeader) {
		String role = extractRoleFromAuthorizationHeader(authorizationHeader);
		UserModel user = convertDtoToModel(dto);
		if ("ADMIN".equals(role)) {
			if (user.getRole().equals("USER")) {
				if (repo.existsById(user.getId())) {
					String errorMessage = "User with ID " + user.getId() + " already exists.";
					return ResponseEntity.status(HttpStatus.CONFLICT).body(errorMessage);
				} else {
					UserModel createdUser = repo.save(user);
					return new ResponseEntity<UserModel>(createdUser, HttpStatus.CREATED);
				}
			} else {
				String errorMessage = "Admin can't create user with role different from 'USER'";
				return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(errorMessage);
			}

		} else if ("OWNER".equals(role)) {
			if (user.getRole().equals("USER") || user.getRole().equals("ADMIN")) {
				UserModel createdUser = repo.save(user);
				return new ResponseEntity<UserModel>(createdUser, HttpStatus.CREATED);
			} else {
				String errorMessage = "Admin can't create user with role different from 'USER'or 'ADMIN";
				return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(errorMessage);
			}
		} else {
			if (user.getRole().equals("OWNER")) {
				if (repo.existsByRole("OWNER")) {
					return ResponseEntity.status(HttpStatus.CONFLICT).body("An user with role 'OWNER' already exists.");
				} else {
					if (repo.existsById(user.getId())) {
						String errorMessage = "User with ID " + user.getId() + " already exists.";
						return ResponseEntity.status(HttpStatus.CONFLICT).body(errorMessage);
					} else {
						UserModel createdUser = repo.save(user);
						return new ResponseEntity<UserModel>(createdUser, HttpStatus.CREATED);
					}
				}
			} else {
				if (repo.existsById(user.getId())) {
					String errorMessage = "User with ID " + user.getId() + " already exists.";
					return ResponseEntity.status(HttpStatus.CONFLICT).body(errorMessage);
				} else {
					UserModel createdUser = repo.save(user);
					return new ResponseEntity<UserModel>(createdUser, HttpStatus.CREATED);
				}
			}
		}
		
	}

	@Override
	public ResponseEntity<?> updateUser(@PathVariable int id,UserDto dto,@RequestHeader("Authorization") String authorizationHeader) {
	
		String role = extractRoleFromAuthorizationHeader(authorizationHeader);
		UserModel user=convertDtoToModel(dto);
		if ("ADMIN".equals(role)) {
			if (user.getRole().equals("USER")) {
				if (repo.existsById(user.getId())) {
					repo.save(user);
					String errorMessage = "User with ID " + user.getId() + " updated.";
					return ResponseEntity.status(HttpStatus.OK).body(errorMessage);
				} else {
					String errorMessage = "User with ID " + user.getId() + " doesn't exists.";
					return ResponseEntity.status(HttpStatus.NOT_FOUND).body(errorMessage);
				}
			} else {
				String errorMessage = "Admin can't update user with role different from 'USER'";
				return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(errorMessage);
			}

		} else if ("OWNER".equals(role)) {
			if (repo.existsById(user.getId())) {
				repo.save(user);
				String errorMessage = "User with ID " + user.getId() + " updated.";
				return ResponseEntity.status(HttpStatus.OK).body(errorMessage);
			} else {
				String errorMessage = "User with ID " + user.getId() + " doesn't exists.";
				return ResponseEntity.status(HttpStatus.NOT_FOUND).body(errorMessage);
			}
		} else {
			if (repo.existsById(user.getId())) {
				repo.save(user);
				String errorMessage = "User with ID " + user.getId() + " updated.";
				return ResponseEntity.status(HttpStatus.OK).body(errorMessage);
			} else {
				String errorMessage = "User with ID " + user.getId() + " doesn't exists.";
				return ResponseEntity.status(HttpStatus.NOT_FOUND).body(errorMessage);
			}
		}
	}
	
	
	
	
	
	
	
	
	
	
	public UserModel convertDtoToModel(UserDto dto) {
		return new UserModel(dto.getEmail(), dto.getPassword(), dto.getRole());
	}
	
	public UserDto convertModelToDto(UserModel model) {
		return new UserDto(model.getEmail(), model.getPassword(), model.getRole());
	}

	public String extractRoleFromAuthorizationHeader(String authorizationHeader) {
		String encodedCredentials = authorizationHeader.replaceFirst("Basic ", "");
		byte[] decodedBytes = Base64.decode(encodedCredentials.getBytes());
		String decodedCredentials = new String(decodedBytes);
		String[] credentials = decodedCredentials.split(":");
		String role = credentials[0]; // prvo se unosi email kao username korisnika
		UserModel user = repo.findByEmail(role);
		return user.getRole();
	}
	public String extractEmailFromAuthorizationHeader(String authorizationHeader) {
		String encodedCredentials = authorizationHeader.replaceFirst("Basic ", "");
		byte[] decodedBytes = Base64.decode(encodedCredentials.getBytes());
		String decodedCredentials = new String(decodedBytes);
		String[] credentials = decodedCredentials.split(":");
		String role = credentials[0]; // prvo se unosi email kao username korisnika
		return role;
	}


	@Override
	public ResponseEntity<?> deleteUser(int id, String authorizationHeader) {
		String role = extractRoleFromAuthorizationHeader(authorizationHeader);
		UserModel user = repo.getById(id);
		// System.out.println("Role: " + role);
		if ("OWNER".equals(role)) {
			if (repo.existsById(id)) {
				if (user.getRole().equals("USER")) {
					proxy.deleteUsersAccount(user.getEmail());
					repo.deleteById(id);
					String successMessage = "User with ID " + id + " deleted.";
					return ResponseEntity.ok(successMessage);
				} else {
					repo.deleteById(id);
					String successMessage = "User with ID " + id + " deleted.";
					return ResponseEntity.ok(successMessage);
				}
			} else {
				String errorMessage = "User with ID " + id + " doesn't exist.";
				return ResponseEntity.status(HttpStatus.NOT_FOUND).body(errorMessage);
			}
		} else {
			String errorMessage = "Only the user with role 'OWNER' can delete all users.";
			return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(errorMessage);
		}
	}


	@Override
	public Boolean getUserByEmail(String email) {
		UserModel user = repo.findByEmail(email);
		if (user == null) {
			return false;
		} else
			return true;
	}


	@Override
	public String getUsersRoleByEmail(String email) {
		UserModel user = repo.findByEmail(email);
		if (user == null) {
			return null;
		} else
			return user.getRole();
	}


	@Override
	public String getCurrentUserRole(String authorizationHeader) {
		String role = extractRoleFromAuthorizationHeader(authorizationHeader);
		return role;
	}


	@Override
	public String getCurrentUserEmail(String authorizationHeader) {
		String email = extractEmailFromAuthorizationHeader(authorizationHeader);
		return email;

	}
	
	
}
