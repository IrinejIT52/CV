insert into user_model(id,email,password,role)
values(1,'admin@gmail.com', '123' ,'ADMIN'),
	   (2, 'user1@gmail.com', '123', 'USER'),
	   (3, 'user2@gmail.com', '123', 'USER'),
	   (4, 'user3@gmail.com', '123', 'USER'),
	   (5, 'owner@gmail.com','123','OWNER');